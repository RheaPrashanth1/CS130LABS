#include "light.h"
#include "phong_shader.h"
#include "ray.h"
#include "render_world.h"
#include "object.h"

vec3 Phong_Shader::Shade_Surface(const Ray& ray,const vec3& intersection_point,const vec3& normal,int recursion_depth) const
{
    vec3 color, distLightInt;
    
  for(unsigned int i = 0; i < world.lights.size();++i) {
   distLightInt = (world.lights.at(i)->position - intersection_point);
double zero = 0.0;
double angle = std::max(dot(normal, distLightInt.normalized()), zero);
vec3 l_color = world.lights.at(i)->Emitted_Light(distLightInt);
vec3 diff = (color_diffuse * l_color * angle); 

color = color + diff; 
  }

    //determine the color
    return color;
}
